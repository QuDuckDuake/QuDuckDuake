package com.example.simpleplugin;

import android.util.Log;

public class SimplePlugin {
    public void logMessage(String message) {
        Log.d("MyPlugin", message);
    }
}
