package com.example.simpleplugin;

import org.junit.Test;

import static org.junit.Assert.*;

public class SimplePluginTest {
    @Test
    public void testLogMessage() {
        SimplePlugin plugin = new SimplePlugin();
        plugin.logMessage("This is a test message.");
    }
}
